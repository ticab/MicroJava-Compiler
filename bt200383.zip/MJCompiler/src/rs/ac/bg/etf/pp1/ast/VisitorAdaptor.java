// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(PreDesignator PreDesignator) { }
    public void visit(Mulop Mulop) { }
    public void visit(ConstValType ConstValType) { }
    public void visit(ForCondFact ForCondFact) { }
    public void visit(Relop Relop) { }
    public void visit(AllDecl AllDecl) { }
    public void visit(DesSt DesSt) { }
    public void visit(StatementList StatementList) { }
    public void visit(NamespaceList NamespaceList) { }
    public void visit(Addop Addop) { }
    public void visit(MethodReturn MethodReturn) { }
    public void visit(OneVar OneVar) { }
    public void visit(Factor Factor) { }
    public void visit(CondTerm CondTerm) { }
    public void visit(Designator Designator) { }
    public void visit(Condition Condition) { }
    public void visit(ForStatementPart ForStatementPart) { }
    public void visit(Factors Factors) { }
    public void visit(DesignatorStatementList DesignatorStatementList) { }
    public void visit(IfCondition IfCondition) { }
    public void visit(DesStList DesStList) { }
    public void visit(MethodVarDecl MethodVarDecl) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(FormalParamList FormalParamList) { }
    public void visit(Expr Expr) { }
    public void visit(ActPars ActPars) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(MultipleConstDecl MultipleConstDecl) { }
    public void visit(ActParamList ActParamList) { }
    public void visit(Statement Statement) { }
    public void visit(MultVar MultVar) { }
    public void visit(CondFact CondFact) { }
    public void visit(MethodDeclList MethodDeclList) { }
    public void visit(ArrayLR ArrayLR) { }
    public void visit(FormPars FormPars) { }
    public void visit(ModuoOper ModuoOper) { visit(); }
    public void visit(DivOper DivOper) { visit(); }
    public void visit(MulOper MulOper) { visit(); }
    public void visit(MinusOper MinusOper) { visit(); }
    public void visit(PlusOper PlusOper) { visit(); }
    public void visit(LessEqOp LessEqOp) { visit(); }
    public void visit(GreaterEqOp GreaterEqOp) { visit(); }
    public void visit(GreaterOp GreaterOp) { visit(); }
    public void visit(LessOp LessOp) { visit(); }
    public void visit(NotEqualOp NotEqualOp) { visit(); }
    public void visit(EqualOper EqualOper) { visit(); }
    public void visit(WithoutDC WithoutDC) { visit(); }
    public void visit(WithDC WithDC) { visit(); }
    public void visit(DesigWithExpr DesigWithExpr) { visit(); }
    public void visit(DesigWithoutExpr DesigWithoutExpr) { visit(); }
    public void visit(FactorExpr FactorExpr) { visit(); }
    public void visit(NewArray NewArray) { visit(); }
    public void visit(FactorBool FactorBool) { visit(); }
    public void visit(FactorChar FactorChar) { visit(); }
    public void visit(FactorNum FactorNum) { visit(); }
    public void visit(FactorFuncCall FactorFuncCall) { visit(); }
    public void visit(FactorVar FactorVar) { visit(); }
    public void visit(OneFactor OneFactor) { visit(); }
    public void visit(MulFactors MulFactors) { visit(); }
    public void visit(Term Term) { visit(); }
    public void visit(PositiveExpr PositiveExpr) { visit(); }
    public void visit(AddExpr AddExpr) { visit(); }
    public void visit(NegativeExpr NegativeExpr) { visit(); }
    public void visit(OrBlock OrBlock) { visit(); }
    public void visit(SingleCondF SingleCondF) { visit(); }
    public void visit(RelopCondF RelopCondF) { visit(); }
    public void visit(SingleCondT SingleCondT) { visit(); }
    public void visit(AndCondT AndCondT) { visit(); }
    public void visit(SingleTermCondition SingleTermCondition) { visit(); }
    public void visit(OrOpTermListCondition OrOpTermListCondition) { visit(); }
    public void visit(SingleExpr SingleExpr) { visit(); }
    public void visit(MultipleExpr MultipleExpr) { visit(); }
    public void visit(NoAct NoAct) { visit(); }
    public void visit(Act Act) { visit(); }
    public void visit(DesStStart DesStStart) { visit(); }
    public void visit(FunctionCallName FunctionCallName) { visit(); }
    public void visit(DesStWithComma DesStWithComma) { visit(); }
    public void visit(DesStWithDes DesStWithDes) { visit(); }
    public void visit(DesStEmpty DesStEmpty) { visit(); }
    public void visit(DesStHas DesStHas) { visit(); }
    public void visit(DesignBC DesignBC) { visit(); }
    public void visit(DesignPostDec DesignPostDec) { visit(); }
    public void visit(DesignPostInc DesignPostInc) { visit(); }
    public void visit(DesignFuncCall DesignFuncCall) { visit(); }
    public void visit(DesignAssign DesignAssign) { visit(); }
    public void visit(EmptyCondFact EmptyCondFact) { visit(); }
    public void visit(WithCondFact WithCondFact) { visit(); }
    public void visit(SignleDesStList SignleDesStList) { visit(); }
    public void visit(MultipleDesStList MultipleDesStList) { visit(); }
    public void visit(ForStatementPartEmpty ForStatementPartEmpty) { visit(); }
    public void visit(ForStatementPartWith ForStatementPartWith) { visit(); }
    public void visit(ForCondStart ForCondStart) { visit(); }
    public void visit(ForEndInc ForEndInc) { visit(); }
    public void visit(ForStartInc ForStartInc) { visit(); }
    public void visit(ForStatement ForStatement) { visit(); }
    public void visit(ForStartStm ForStartStm) { visit(); }
    public void visit(ForStart ForStart) { visit(); }
    public void visit(EmptyIfElse EmptyIfElse) { visit(); }
    public void visit(EndIf EndIf) { visit(); }
    public void visit(StartIf StartIf) { visit(); }
    public void visit(ErrorInCondition ErrorInCondition) { visit(); }
    public void visit(IfPart IfPart) { visit(); }
    public void visit(NoStatements NoStatements) { visit(); }
    public void visit(NonEmptyStement NonEmptyStement) { visit(); }
    public void visit(MultipleStatement MultipleStatement) { visit(); }
    public void visit(StatementFor StatementFor) { visit(); }
    public void visit(PrintStatementWit PrintStatementWit) { visit(); }
    public void visit(PrintStatement PrintStatement) { visit(); }
    public void visit(StatementRead StatementRead) { visit(); }
    public void visit(StatementReturnExpr StatementReturnExpr) { visit(); }
    public void visit(StatementReturn StatementReturn) { visit(); }
    public void visit(StatementContinue StatementContinue) { visit(); }
    public void visit(StatementBreak StatementBreak) { visit(); }
    public void visit(StatementIfElse StatementIfElse) { visit(); }
    public void visit(StatementIf StatementIf) { visit(); }
    public void visit(ErrorInDesignatorAssignOperation ErrorInDesignatorAssignOperation) { visit(); }
    public void visit(StatementDesignator StatementDesignator) { visit(); }
    public void visit(Type Type) { visit(); }
    public void visit(IsntArray IsntArray) { visit(); }
    public void visit(IsArray IsArray) { visit(); }
    public void visit(FormalParamDecl FormalParamDecl) { visit(); }
    public void visit(ErrorInListOfParams ErrorInListOfParams) { visit(); }
    public void visit(ErrorInFormalParam ErrorInFormalParam) { visit(); }
    public void visit(SingleFormalParam SingleFormalParam) { visit(); }
    public void visit(MultipleFormalParams MultipleFormalParams) { visit(); }
    public void visit(NoFormalParams NoFormalParams) { visit(); }
    public void visit(FormalParams FormalParams) { visit(); }
    public void visit(NoVarsInMethod NoVarsInMethod) { visit(); }
    public void visit(MethodVars MethodVars) { visit(); }
    public void visit(ReturnVoid ReturnVoid) { visit(); }
    public void visit(ReturnSomething ReturnSomething) { visit(); }
    public void visit(MethodFullName MethodFullName) { visit(); }
    public void visit(MethodDecl MethodDecl) { visit(); }
    public void visit(EmptyMethodDeclList EmptyMethodDeclList) { visit(); }
    public void visit(MultipleMethodDecl MultipleMethodDecl) { visit(); }
    public void visit(ErrorOneVar ErrorOneVar) { visit(); }
    public void visit(OneVarDec OneVarDec) { visit(); }
    public void visit(ErrorMulteVar ErrorMulteVar) { visit(); }
    public void visit(VarFromMultiple VarFromMultiple) { visit(); }
    public void visit(SingleVarDecl SingleVarDecl) { visit(); }
    public void visit(MultipleVarDecl MultipleVarDecl) { visit(); }
    public void visit(VarDeclType VarDeclType) { visit(); }
    public void visit(VarDecl VarDecl) { visit(); }
    public void visit(WithoutConstDecl WithoutConstDecl) { visit(); }
    public void visit(WithConstDecl WithConstDecl) { visit(); }
    public void visit(BoolVal BoolVal) { visit(); }
    public void visit(CharVal CharVal) { visit(); }
    public void visit(IntVal IntVal) { visit(); }
    public void visit(ConstValueEq ConstValueEq) { visit(); }
    public void visit(ConstType ConstType) { visit(); }
    public void visit(ConstDecl ConstDecl) { visit(); }
    public void visit(NamespaceName NamespaceName) { visit(); }
    public void visit(Namespace Namespace) { visit(); }
    public void visit(WithoutNamespace WithoutNamespace) { visit(); }
    public void visit(WithNamespace WithNamespace) { visit(); }
    public void visit(NoDeclarations NoDeclarations) { visit(); }
    public void visit(ConstDeclarations ConstDeclarations) { visit(); }
    public void visit(VarDeclarations VarDeclarations) { visit(); }
    public void visit(ProgName ProgName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
