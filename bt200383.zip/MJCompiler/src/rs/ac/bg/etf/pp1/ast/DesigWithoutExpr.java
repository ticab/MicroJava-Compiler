// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class DesigWithoutExpr extends Designator {

    private PreDesignator PreDesignator;

    public DesigWithoutExpr (PreDesignator PreDesignator) {
        this.PreDesignator=PreDesignator;
        if(PreDesignator!=null) PreDesignator.setParent(this);
    }

    public PreDesignator getPreDesignator() {
        return PreDesignator;
    }

    public void setPreDesignator(PreDesignator PreDesignator) {
        this.PreDesignator=PreDesignator;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(PreDesignator!=null) PreDesignator.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(PreDesignator!=null) PreDesignator.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(PreDesignator!=null) PreDesignator.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesigWithoutExpr(\n");

        if(PreDesignator!=null)
            buffer.append(PreDesignator.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesigWithoutExpr]");
        return buffer.toString();
    }
}
