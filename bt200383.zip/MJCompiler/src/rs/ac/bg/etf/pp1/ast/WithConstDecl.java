// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class WithConstDecl extends MultipleConstDecl {

    private MultipleConstDecl MultipleConstDecl;
    private ConstValueEq ConstValueEq;

    public WithConstDecl (MultipleConstDecl MultipleConstDecl, ConstValueEq ConstValueEq) {
        this.MultipleConstDecl=MultipleConstDecl;
        if(MultipleConstDecl!=null) MultipleConstDecl.setParent(this);
        this.ConstValueEq=ConstValueEq;
        if(ConstValueEq!=null) ConstValueEq.setParent(this);
    }

    public MultipleConstDecl getMultipleConstDecl() {
        return MultipleConstDecl;
    }

    public void setMultipleConstDecl(MultipleConstDecl MultipleConstDecl) {
        this.MultipleConstDecl=MultipleConstDecl;
    }

    public ConstValueEq getConstValueEq() {
        return ConstValueEq;
    }

    public void setConstValueEq(ConstValueEq ConstValueEq) {
        this.ConstValueEq=ConstValueEq;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(MultipleConstDecl!=null) MultipleConstDecl.accept(visitor);
        if(ConstValueEq!=null) ConstValueEq.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(MultipleConstDecl!=null) MultipleConstDecl.traverseTopDown(visitor);
        if(ConstValueEq!=null) ConstValueEq.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(MultipleConstDecl!=null) MultipleConstDecl.traverseBottomUp(visitor);
        if(ConstValueEq!=null) ConstValueEq.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("WithConstDecl(\n");

        if(MultipleConstDecl!=null)
            buffer.append(MultipleConstDecl.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ConstValueEq!=null)
            buffer.append(ConstValueEq.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [WithConstDecl]");
        return buffer.toString();
    }
}
