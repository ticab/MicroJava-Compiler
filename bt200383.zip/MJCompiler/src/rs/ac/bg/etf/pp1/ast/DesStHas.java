// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class DesStHas extends DesSt {

    private DesSt DesSt;
    private DesStList DesStList;

    public DesStHas (DesSt DesSt, DesStList DesStList) {
        this.DesSt=DesSt;
        if(DesSt!=null) DesSt.setParent(this);
        this.DesStList=DesStList;
        if(DesStList!=null) DesStList.setParent(this);
    }

    public DesSt getDesSt() {
        return DesSt;
    }

    public void setDesSt(DesSt DesSt) {
        this.DesSt=DesSt;
    }

    public DesStList getDesStList() {
        return DesStList;
    }

    public void setDesStList(DesStList DesStList) {
        this.DesStList=DesStList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesSt!=null) DesSt.accept(visitor);
        if(DesStList!=null) DesStList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesSt!=null) DesSt.traverseTopDown(visitor);
        if(DesStList!=null) DesStList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesSt!=null) DesSt.traverseBottomUp(visitor);
        if(DesStList!=null) DesStList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesStHas(\n");

        if(DesSt!=null)
            buffer.append(DesSt.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DesStList!=null)
            buffer.append(DesStList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesStHas]");
        return buffer.toString();
    }
}
