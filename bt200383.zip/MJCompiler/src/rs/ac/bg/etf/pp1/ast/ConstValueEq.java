// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class ConstValueEq implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private String constName;
    private ConstValType ConstValType;

    public ConstValueEq (String constName, ConstValType ConstValType) {
        this.constName=constName;
        this.ConstValType=ConstValType;
        if(ConstValType!=null) ConstValType.setParent(this);
    }

    public String getConstName() {
        return constName;
    }

    public void setConstName(String constName) {
        this.constName=constName;
    }

    public ConstValType getConstValType() {
        return ConstValType;
    }

    public void setConstValType(ConstValType ConstValType) {
        this.ConstValType=ConstValType;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstValType!=null) ConstValType.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstValType!=null) ConstValType.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstValType!=null) ConstValType.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConstValueEq(\n");

        buffer.append(" "+tab+constName);
        buffer.append("\n");

        if(ConstValType!=null)
            buffer.append(ConstValType.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConstValueEq]");
        return buffer.toString();
    }
}
