package rs.ac.bg.etf.pp1;

import rs.etf.pp1.symboltable.concepts.Struct;

public class TabExtended {
	public static final Struct boolType = new Struct(Struct.Bool);
}
