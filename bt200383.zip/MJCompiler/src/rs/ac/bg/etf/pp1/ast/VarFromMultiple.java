// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class VarFromMultiple extends MultVar {

    private String varName;
    private ArrayLR ArrayLR;

    public VarFromMultiple (String varName, ArrayLR ArrayLR) {
        this.varName=varName;
        this.ArrayLR=ArrayLR;
        if(ArrayLR!=null) ArrayLR.setParent(this);
    }

    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName=varName;
    }

    public ArrayLR getArrayLR() {
        return ArrayLR;
    }

    public void setArrayLR(ArrayLR ArrayLR) {
        this.ArrayLR=ArrayLR;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ArrayLR!=null) ArrayLR.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ArrayLR!=null) ArrayLR.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ArrayLR!=null) ArrayLR.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarFromMultiple(\n");

        buffer.append(" "+tab+varName);
        buffer.append("\n");

        if(ArrayLR!=null)
            buffer.append(ArrayLR.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarFromMultiple]");
        return buffer.toString();
    }
}
