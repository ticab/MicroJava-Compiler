// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class DesignBC extends DesignatorStatement {

    private DesStStart DesStStart;
    private DesSt DesSt;
    private Designator Designator;
    private Designator Designator1;

    public DesignBC (DesStStart DesStStart, DesSt DesSt, Designator Designator, Designator Designator1) {
        this.DesStStart=DesStStart;
        if(DesStStart!=null) DesStStart.setParent(this);
        this.DesSt=DesSt;
        if(DesSt!=null) DesSt.setParent(this);
        this.Designator=Designator;
        if(Designator!=null) Designator.setParent(this);
        this.Designator1=Designator1;
        if(Designator1!=null) Designator1.setParent(this);
    }

    public DesStStart getDesStStart() {
        return DesStStart;
    }

    public void setDesStStart(DesStStart DesStStart) {
        this.DesStStart=DesStStart;
    }

    public DesSt getDesSt() {
        return DesSt;
    }

    public void setDesSt(DesSt DesSt) {
        this.DesSt=DesSt;
    }

    public Designator getDesignator() {
        return Designator;
    }

    public void setDesignator(Designator Designator) {
        this.Designator=Designator;
    }

    public Designator getDesignator1() {
        return Designator1;
    }

    public void setDesignator1(Designator Designator1) {
        this.Designator1=Designator1;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesStStart!=null) DesStStart.accept(visitor);
        if(DesSt!=null) DesSt.accept(visitor);
        if(Designator!=null) Designator.accept(visitor);
        if(Designator1!=null) Designator1.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesStStart!=null) DesStStart.traverseTopDown(visitor);
        if(DesSt!=null) DesSt.traverseTopDown(visitor);
        if(Designator!=null) Designator.traverseTopDown(visitor);
        if(Designator1!=null) Designator1.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesStStart!=null) DesStStart.traverseBottomUp(visitor);
        if(DesSt!=null) DesSt.traverseBottomUp(visitor);
        if(Designator!=null) Designator.traverseBottomUp(visitor);
        if(Designator1!=null) Designator1.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignBC(\n");

        if(DesStStart!=null)
            buffer.append(DesStStart.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DesSt!=null)
            buffer.append(DesSt.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Designator!=null)
            buffer.append(Designator.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Designator1!=null)
            buffer.append(Designator1.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignBC]");
        return buffer.toString();
    }
}
