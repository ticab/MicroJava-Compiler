// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class ErrorInCondition extends IfCondition {

    private StartIf StartIf;
    private EndIf EndIf;

    public ErrorInCondition (StartIf StartIf, EndIf EndIf) {
        this.StartIf=StartIf;
        if(StartIf!=null) StartIf.setParent(this);
        this.EndIf=EndIf;
        if(EndIf!=null) EndIf.setParent(this);
    }

    public StartIf getStartIf() {
        return StartIf;
    }

    public void setStartIf(StartIf StartIf) {
        this.StartIf=StartIf;
    }

    public EndIf getEndIf() {
        return EndIf;
    }

    public void setEndIf(EndIf EndIf) {
        this.EndIf=EndIf;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(StartIf!=null) StartIf.accept(visitor);
        if(EndIf!=null) EndIf.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(StartIf!=null) StartIf.traverseTopDown(visitor);
        if(EndIf!=null) EndIf.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(StartIf!=null) StartIf.traverseBottomUp(visitor);
        if(EndIf!=null) EndIf.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ErrorInCondition(\n");

        if(StartIf!=null)
            buffer.append(StartIf.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(EndIf!=null)
            buffer.append(EndIf.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ErrorInCondition]");
        return buffer.toString();
    }
}
