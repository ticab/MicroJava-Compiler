// generated with ast extension for cup
// version 0.8
// 3/1/2024 12:33:35


package rs.ac.bg.etf.pp1.ast;

public class ForStatement implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private ForStatementPart ForStatementPart;
    private ForCondStart ForCondStart;
    private ForCondFact ForCondFact;
    private ForStartInc ForStartInc;
    private ForStatementPart ForStatementPart1;
    private ForEndInc ForEndInc;

    public ForStatement (ForStatementPart ForStatementPart, ForCondStart ForCondStart, ForCondFact ForCondFact, ForStartInc ForStartInc, ForStatementPart ForStatementPart1, ForEndInc ForEndInc) {
        this.ForStatementPart=ForStatementPart;
        if(ForStatementPart!=null) ForStatementPart.setParent(this);
        this.ForCondStart=ForCondStart;
        if(ForCondStart!=null) ForCondStart.setParent(this);
        this.ForCondFact=ForCondFact;
        if(ForCondFact!=null) ForCondFact.setParent(this);
        this.ForStartInc=ForStartInc;
        if(ForStartInc!=null) ForStartInc.setParent(this);
        this.ForStatementPart1=ForStatementPart1;
        if(ForStatementPart1!=null) ForStatementPart1.setParent(this);
        this.ForEndInc=ForEndInc;
        if(ForEndInc!=null) ForEndInc.setParent(this);
    }

    public ForStatementPart getForStatementPart() {
        return ForStatementPart;
    }

    public void setForStatementPart(ForStatementPart ForStatementPart) {
        this.ForStatementPart=ForStatementPart;
    }

    public ForCondStart getForCondStart() {
        return ForCondStart;
    }

    public void setForCondStart(ForCondStart ForCondStart) {
        this.ForCondStart=ForCondStart;
    }

    public ForCondFact getForCondFact() {
        return ForCondFact;
    }

    public void setForCondFact(ForCondFact ForCondFact) {
        this.ForCondFact=ForCondFact;
    }

    public ForStartInc getForStartInc() {
        return ForStartInc;
    }

    public void setForStartInc(ForStartInc ForStartInc) {
        this.ForStartInc=ForStartInc;
    }

    public ForStatementPart getForStatementPart1() {
        return ForStatementPart1;
    }

    public void setForStatementPart1(ForStatementPart ForStatementPart1) {
        this.ForStatementPart1=ForStatementPart1;
    }

    public ForEndInc getForEndInc() {
        return ForEndInc;
    }

    public void setForEndInc(ForEndInc ForEndInc) {
        this.ForEndInc=ForEndInc;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ForStatementPart!=null) ForStatementPart.accept(visitor);
        if(ForCondStart!=null) ForCondStart.accept(visitor);
        if(ForCondFact!=null) ForCondFact.accept(visitor);
        if(ForStartInc!=null) ForStartInc.accept(visitor);
        if(ForStatementPart1!=null) ForStatementPart1.accept(visitor);
        if(ForEndInc!=null) ForEndInc.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ForStatementPart!=null) ForStatementPart.traverseTopDown(visitor);
        if(ForCondStart!=null) ForCondStart.traverseTopDown(visitor);
        if(ForCondFact!=null) ForCondFact.traverseTopDown(visitor);
        if(ForStartInc!=null) ForStartInc.traverseTopDown(visitor);
        if(ForStatementPart1!=null) ForStatementPart1.traverseTopDown(visitor);
        if(ForEndInc!=null) ForEndInc.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ForStatementPart!=null) ForStatementPart.traverseBottomUp(visitor);
        if(ForCondStart!=null) ForCondStart.traverseBottomUp(visitor);
        if(ForCondFact!=null) ForCondFact.traverseBottomUp(visitor);
        if(ForStartInc!=null) ForStartInc.traverseBottomUp(visitor);
        if(ForStatementPart1!=null) ForStatementPart1.traverseBottomUp(visitor);
        if(ForEndInc!=null) ForEndInc.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ForStatement(\n");

        if(ForStatementPart!=null)
            buffer.append(ForStatementPart.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ForCondStart!=null)
            buffer.append(ForCondStart.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ForCondFact!=null)
            buffer.append(ForCondFact.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ForStartInc!=null)
            buffer.append(ForStartInc.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ForStatementPart1!=null)
            buffer.append(ForStatementPart1.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ForEndInc!=null)
            buffer.append(ForEndInc.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ForStatement]");
        return buffer.toString();
    }
}
